package fr.ensim.tp2.tp5.model;

public class Adresse {
	private String adresse;
	public String getAdresse() {
		return adresse;
	}
	public void setAdresse(String adresse) {
		this.adresse=adresse;
	}
}
